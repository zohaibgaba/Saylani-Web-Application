//q1
//   function  telldate(){
//     var a=new Date()
//    document.write(a)
// }

// telldate();

// q2
// function greeting() {
//     var fname = prompt('enter the first name')
//     var lname = prompt('enter the last name ')
//     var merge = fname + " " + lname
//     document.write("Welcome " + merge)
// }
// greeting();

//q3
// function addnum( a,b){
//   return a+b
// }

// alert(addnum(2,3))


//q4
// functon cal  (a, b,c) {
//     var ans;
//     if(b==='+'){
//         ans= a+c
//     }
//     else if(b==='-'){
//        ans = a-c
//     }else if(b==='*'){
//        ans = a*c
//     }else(b==='/'){
//        ans = a/c
//     }


//     return ans
// }

//q5

// function square(a){
//     return a*a
// }

// alert(square(6))


// Q6
// function fact(a){
//     var x=1
//     for(var i=1;i<=a;i++){
//      x=x*i

//     }
// return x
// }

// alert(fact(3))

//q7
// function count(a, b) {
//     for (var i = a; i <=b; i++) {
//     document.write(i + "<br/>")
// }
// }
// count(1,10)


//q8

// function base(a){
//     return a*a
// }
// function perpend(b){
//     return b*b
// }

// function calhyp(a,b){
//     var z=base(a)+perpend(b)
    
//     return Math.sqrt(z)
// }

// q9
// function area(a,b){
//     return a*b
// }
// alert("i) " +area(1,2))
// a=1
// b=2
// alert("ii) " +area(a,b))
//q10
// function check(){
//        var a=prompt("enter the name")
//      a =a.toLowerCase()
//      var j=a.length
//      var z=0
//      for(var i=0;i<=a.length;i++){
//          if(a[i]===a[j]){
//           z=z+1
//          }
//         j=j-1
//      }
     
//      if(z===a.lenght){
//         return true
//     }else{
//         return false
//     }
    
// }

// if(check()===true){
//     alert("it is plaindrome")
// }
// else {
//     alert("it is not plaindrome")
// }


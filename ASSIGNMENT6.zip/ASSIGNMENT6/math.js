
//question 1
// var  a =prompt("enter the number")

// if(a<0){
//    alert("write postive value");

// }
// else{
// document.write("the number is "+ a + "<br/>" )
// document.write("the rounded value is : "+ Math.round(a)+ "<br/>" )
// document.write("the floor value is : "+ Math.floor(a) + "<br/>" )
// document.write("the ceil value is : "+ Math.ceil(a) + "<br/>" )
// }



// // q2
// var  a =prompt("enter the number")

// if(a>0){
//    alert("write negative value");

// }
// else{
// document.write("the number is "+ a + "<br/>" )
// document.write("the rounded value is : "+ Math.round(a)+ "<br/>" )
// document.write("the floor value is : "+ Math.floor(a) + "<br/>" )
// document.write("the ceil value is : "+ Math.ceil(a) + "<br/>" )
// }



//q3
// var a=prompt('enter the number')
// alert("the absolute value of "+ a +" is "+ Math.abs(a))

//q4
// var a= Math.random();
// var b=(a*6)+1
// var final =Math.floor(b);
// alert( "The disc is :" + final)


//q5
// var a= Math.random();
// var b=(a*2)+1
// var final =Math.floor(b);
// if(final===2){
//   alert("Head")
// }
// else{
//     alert("Tail")

// }

// q6
// var a= Math.random();
// var b=(a*100)+1
// alert("the eandom number between 1 and 100 is : "   + Math.floor(b) )

// q7
//??
//q8
// var a= Math.random();
// var b=(a*10)+1
// b=Math.floor(b)
// var guess=prompt("Enter the guessed number")
// if(guess===b){
//     alert("Congratulation you won ")
// }else{
//     alert(" You lost guess number is : " + b )

// }